# AI Trading Assistant — Manual Mode (React + FastAPI)
This is a lightweight **starter project** for the AI Manual Trading Assistant you requested.
It captures a selected screen/window in the browser (you choose what to share), sends frames to a local FastAPI backend,
and the backend returns a dummy trading signal. All execution is local and manual — no automatic order placement.

## What's included
- `frontend/` — Minimal React app (Vite-style structure) with screen capture & floating signal widget.
- `backend/` — FastAPI app with endpoints to receive frames, run OCR stub, compute indicators stub, and return a dummy prediction.
- `models/` — placeholder for model files.
- `run_frontend.sh` and `run_backend.sh` — quick run scripts.

## Quick start (Linux / WSL / macOS)
1. Backend:
   - `cd backend`
   - `python3 -m venv .venv && source .venv/bin/activate`
   - `pip install -r requirements.txt`
   - `uvicorn main:app --reload --host 127.0.0.1 --port 8000`
2. Frontend:
   - `cd frontend`
   - `npm install` (or `pnpm`/`yarn`)
   - `npm run dev` (Vite default — app served on http://localhost:5173)
3. Open the frontend in your browser, click "Start Capture", and allow capturing the chart window.

## Notes
- This is a starter skeleton. OCR, real model, and robust feature extraction are provided as stubs that you can replace with real implementations.
- All processing runs locally by default. No keys, no cloud required.
