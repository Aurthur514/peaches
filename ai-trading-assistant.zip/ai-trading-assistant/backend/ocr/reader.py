# Simple OCR stub — replace with Tesseract/EasyOCR for production.
from PIL import Image
import io

def extract_numbers(image_bytes):
    # For demo: we don't run OCR. Instead, return a small structure
    # that mimics parsed values from a chart.
    # Replace this with real OCR logic.
    return {
        'last_price': 100.0,
        'candles': [],  # placeholder
        'indicators': {
            'EMA20': 99.5,
            'EMA50': 100.2,
            'RSI': 30
        }
    }
