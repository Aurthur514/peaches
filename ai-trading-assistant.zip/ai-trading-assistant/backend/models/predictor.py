# Dummy predictor — replace with a real model (ONNX/Pickle)
def predict_signal(features):
    # very simple heuristic for demo
    ema20 = features.get('ema20', 0)
    ema50 = features.get('ema50', 0)
    rsi = features.get('rsi', 50)
    explanations = features.get('explanations', [])

    # Compute a dummy probability
    score = 0.5
    if ema20 > ema50:
        score += 0.15
    else:
        score -= 0.1
    if rsi < 35:
        score += 0.1
    if score > 0.99: score = 0.99
    if score < 0.01: score = 0.01

    if score > 0.65:
        signal = 'BUY'
    elif score < 0.35:
        signal = 'SELL'
    else:
        signal = 'NO TRADE'

    return {
        'signal': signal,
        'confidence': round(score, 3),
        'expected_move_5min': '+0.4%' if signal == 'BUY' else ('-0.3%' if signal == 'SELL' else '0%'),
        'reason': explanations
    }
