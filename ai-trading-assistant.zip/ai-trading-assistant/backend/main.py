from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from ocr.reader import extract_numbers
from indicators.compute import compute_features
from models.predictor import predict_signal
import io

app = FastAPI(title='AI Trading Assistant Backend')

@app.post('/process-frame')
async def process_frame(frame: UploadFile = File(...)):
    try:
        contents = await frame.read()
        # OCR stub: extract numbers/text from the image/frame
        ocr_data = extract_numbers(contents)

        # Compute indicators/features stub
        features = compute_features(ocr_data)

        # Predict signal (dummy model)
        result = predict_signal(features)
        return JSONResponse(content=result)
    except Exception as e:
        return JSONResponse(content={'error': str(e)}, status_code=500)
