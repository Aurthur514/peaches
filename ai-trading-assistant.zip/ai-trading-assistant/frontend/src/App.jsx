import React, { useState } from 'react';
import { startCapture } from './screen-capture';
import './styles.css';

export default function App(){
  const [running, setRunning] = useState(false);
  const [signal, setSignal] = useState(null);

  const handleFrame = async (blob) => {
    try{
      const fd = new FormData();
      fd.append('frame', blob, 'frame.jpg');
      const res = await fetch('http://127.0.0.1:8000/process-frame', {
        method: 'POST',
        body: fd
      });
      const data = await res.json();
      setSignal(data);
    }catch(e){
      console.error('frame send error', e);
    }
  };

  const toggle = async () => {
    if(!running){
      await startCapture(handleFrame);
      setRunning(true);
    } else {
      // currently capture stream is not stoppable from here in this simple demo
      alert('Refresh page to stop capture (demo limitation)');
    }
  };

  return (
    <div className="app">
      <h1>AI Trading Assistant — Manual Mode</h1>
      <p>Click <b>Start Capture</b> and choose the chart/window you want the assistant to see.</p>
      <button onClick={toggle}>{running ? 'Capturing...' : 'Start Capture'}</button>

      <div id="signalBox" className="signalBox" style={{display: signal ? 'block' : 'none'}}>
        {signal && <div>
          <h2>{signal.signal} — {(signal.confidence*100).toFixed(1)}%</h2>
          <p>Expect: {signal.expected_move_5min}</p>
          <p>Reason:</p>
          <ul>{signal.reason.map((r,i)=><li key={i}>{r}</li>)}</ul>
        </div>}
      </div>
    </div>
  );
}
